package com.example.buchhanldungservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuchhandlungserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
