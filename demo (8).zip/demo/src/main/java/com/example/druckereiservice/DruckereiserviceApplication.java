package com.example.druckereiservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DruckereiserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DruckereiserviceApplication.class, args);
	}

}
