package com.example.druckereiservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DruckereiserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
