package com.example.bestellungservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BestellungsserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
