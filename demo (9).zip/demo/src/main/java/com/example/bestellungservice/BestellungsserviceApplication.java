package com.example.bestellungservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BestellungsserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BestellungsserviceApplication.class, args);
	}

}
